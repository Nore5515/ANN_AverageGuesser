# ANN_AverageGuesser
My attempts to make an ANN that can figure out an average between two numbers.
